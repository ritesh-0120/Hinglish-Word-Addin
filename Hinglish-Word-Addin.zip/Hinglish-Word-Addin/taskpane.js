// Toggle AI Suggestions
let aiEnabled = false;

function toggleFeature() {
    aiEnabled = !aiEnabled;
    alert(aiEnabled ? "AI Suggestions Enabled" : "AI Suggestions Disabled");
}

// Hinglish to Hindi conversion (Sample)
function convertHinglishToHindi(text) {
    const mapping = {
        "namaste": "नमस्ते",
        "kaise ho": "कैसे हो"
    };
    return text.split(' ').map(word => mapping[word] || word).join(' ');
}

// Hindi to Kruti Dev conversion (Sample)
function convertToKrutiDev(text) {
    const mapping = {
        "अ": "v",
        "आ": "vk",
        "इ": "b",
        "ई": "B",
    };
    return text.split('').map(char => mapping[char] || char).join('');
}

// Convert Hinglish to Kruti Dev
function convertText() {
    let hinglishText = document.getElementById("hinglishInput").value;
    let hindiText = convertHinglishToHindi(hinglishText);
    let krutiDevText = convertToKrutiDev(hindiText);
    document.getElementById("convertedText").innerText = krutiDevText;
}

// Insert into Microsoft Word
async function insertIntoWord() {
    await Word.run(async (context) => {
        const selection = context.document.getSelection();
        selection.insertText(document.getElementById("convertedText").innerText, "Replace");
        await context.sync();
    });
}

// Voice Typing
function startVoiceTyping() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = "hi-IN";
    recognition.start();

    recognition.onresult = function(event) {
        document.getElementById("hinglishInput").value += event.results[0][0].transcript + " ";
    };
}
